import UIKit

var str = "Hello, playground"

var movies: Set<String> = [     // Set<String> => Set do tipo string
    "Matrix",                  //nao da pra fazer inferencia de tipo, igual como controí um array
    "Vingadores",
    "Jurassic Park",
    "De Volta para o Futuro",
]

var movies2 = Set<String>() //iniciando um set e atribuindo um valor void (vazio)

//inserir valores no set

movies.insert("Homem Aranha: De Volta ao Lar")
print(movies.count) //mostra a quantidade de elementos

movies.insert("Homem Aranha: De Volta ao Lar") //Set aceita repetir valores , quando chamamos um metodo ele devolve um objeto chamado tupla.
print(movies.count)


let result = movies.insert("Homem Aranha: De Volta ao Lar") //atribuir uma variavel chamada result
print(result.inserted, result.memberAfterInsert) // inserted = qual foi inserido , memberAfeter Inserted se realmente ele foi ou nao inserido

// Remover valores
movies.remove("Homem Aranha: De Volta ao Lar")
//movies.removeAll() // remove todos os elementos

//para cada filme dentro da lista de filmes vou imprimir o proprio filmes
// exemplo de for, assim como percorre um set

for movie in movies {
    print(movie)
}

// Para saber se um elemento existe ou não
// se(if) a lista de filmes(movies) contem o filmes
if movies.contains("Matrix"){  //contains = contém
    print("Filme Matrix está na minha lista de favoritos!")
}

